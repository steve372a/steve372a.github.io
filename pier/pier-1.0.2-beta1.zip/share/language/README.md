# pier 语言文件夹
该文件夹用于存放 pier 软件的语言文件，切勿删除否则将无法显示语言。
![](https://img.gejiba.com/images/32885f268561e6d85c43be46e74e6ff8.png)
<center>删除的后果！</center>