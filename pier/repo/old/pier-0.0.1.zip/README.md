# pier
pier 是一个 BAT 构成的软件包管理器，他轻量、便捷、好用。

## 安装软件

这里以腾讯 QQ 为例子，CMD 窗口输入：
```
pier install qq
```
就这样，就能安装好qq。

## 卸载软件

卸载软件也很简单，CMD 窗口输入：
```
pier remove qq
```
这样，QQ就卸载了。

# pier GUI

提供基础图形操作，支持切换语言。
![](https://img.gejiba.com/images/d8aef401cd42f71be27c5270d80abe8f.png)