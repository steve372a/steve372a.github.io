## 这是什么？
这是 Pier 组件中，GUI 部分的源代码。
基于 Visual Basic 6.0 语言编写。